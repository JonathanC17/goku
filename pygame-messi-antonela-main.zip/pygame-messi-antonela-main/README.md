# pygame-messi-antonela
Este proyecto consiste en crear un juego de disparos (Space Shooter) inspirado en el Día de San Valentín usando [PyGame](https://pypi.org/project/pygame/). La nave defensora es [Lionel Messi](https://www.instagram.com/leomessi/), la nave atacante es [Antonela Roccuzzo](https://www.instagram.com/antonelaroccuzzo/), los disparos son corazones y el fondo (espacio donde se desarrolla el el juego) está relacionado al amor.

Se puede personalizar las imágenes y los tamaños de cada uno de los 4 elementos mencionados y la velocidad de los elementos en movimiento (naves y disparos).

### 🛸 Demo: [Video](https://www.instagram.com/reel/C3DhflnLKhH/)
